const Reg=require('../models/reg')
const bcrypt=require('bcrypt')//module
const nodemailer=require('nodemailer')//module
const session=require('express-session')
const multer=require('multer')




exports.loginpage=(req,res)=>{
    try{
    res.render('login.ejs',{message:''})
    }catch(error){
        res.send(error.message)
    }
}

exports.signuppage=(req,res)=>{
    try{
    res.render('signup.ejs',{message:''})
    }catch(error){
        res.send(error.message)
    }
}

exports.registration=async(req,res)=>{
    const {email,pass}=req.body
    const convertpass=await bcrypt.hash(pass,10)
    //console.log(convertpass)
    try{
        const usercheck=await Reg.findOne({email:email})
    //console.log(usercheck)
    if(usercheck==null){
    const record=new Reg({email:email,password:convertpass})
    record.save()

    let testAccount = await nodemailer.createTestAccount();

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        user: 'deepdd4148@gmail.com', // generated ethereal user
        pass: 'fezkbfuxsokragfv', // generated ethereal password
      },
     });
     console.log('Connected to gmail SMTP server')

     let info = await transporter.sendMail({
        from: 'deepdd4148@gmail.com', // sender address
        to: email, // list of receivers
        subject: "Email Verification link-projectcms", // Subject line
        text: "Please click on below link To Verify and Activate your Account", // plain text body
        html: `<a href="http://localhost:5000/emailactivelink/${email}">Click here to Activate your Account</a>`, // html body
      });
      console.log('Email verification Link sent successfully')

    res.render('signup.ejs',{message:'Account has been created successfully.To activate account email verification is must.please check your email.'})
    }else{
        res.render('signup.ejs',{message:'Email already registered with us'})
    }
    }catch(error){
        //console.log(error)
        res.send(error.message)
    }
    
}

exports.logincheck=async(req,res)=>{
    //console.log(req.body)
    const{email,pass}=req.body
    try{
    const record=await Reg.findOne({email:email})
    //console.log(record)
    if(record!==null){
        const passwordcheck=await bcrypt.compare(pass,record.password)
        //console.log(passwordcheck)
        if(passwordcheck){
            req.session.isAuth=true
            req.session.loginname=email
            req.session.role=record.role
            if(record.email=='admin@gmail.com'||record.email=='admin1@gmail.com'){
                res.redirect('/admin/dashboard')
            }else if(record.status=='unverified'){
                res.render('login.ejs',{message:'your email account is not verified yet. please check your email and verify first'})
            }else{
                res.redirect('/userprofiles')
            }
        }else{
            res.render('login.ejs',{message:'Wrong credentials'})
        }
    }else{
        res.render('login.ejs',{message:'Wrong credentials'})
    }
    }catch(error){
        res.send(error.message)
    }
}
exports.forgotform=(req,res)=>{
    try{
    res.render('forgotform.ejs',{message:''})
    }catch(error){
        res.send(error.message)
    }
}
exports.sendlink=async(req,res)=>{
    //console.log(req.body)
    const {email}=req.body
    try{
    const record=await Reg.findOne({email:email})
    //console.log(record)
    if(record==null){
        res.render('forgotform.ejs',{message:'Email is not registered with us'})
    }else{
        let testAccount = await nodemailer.createTestAccount();

  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: 'deepdd4148@gmail.com', // generated ethereal user
      pass: 'fezkbfuxsokragfv', // generated ethereal password
    },
   });
    
    console.log('Connected to gmail SMTP server')

    let info = await transporter.sendMail({
        from: 'deepdd4148@gmail.com', // sender address
        to: email, // list of receivers
        subject: "Forgot password link-projectcms", // Subject line
        text: "Please click on below link for reset your password", // plain text body
        html: `<a href="http://localhost:5000/resetpasswordform/${email}">Click here to change password</a>`, // html body
      });
      console.log('Link sent successfully')
      res.render('forgotform.ejs',{message:'Link has been sent successfully.Please check your email'})
    } 
    }catch(error){
        res.send(error.message)
    }  
}

exports.resetpasswordform=(req,res)=>{
    //console.log(req.params.email)
    try{
    const email=req.params.email
    res.render('resetpasswordform.ejs',{email})
    }catch(error){
        res.send(error.message)
    }
}
exports.resetpasswordnow=async(req,res)=>{
    //console.log(req.params.email)
    //console.log(req.body)
    try{
    const email=req.params.email
    const record=await Reg.findOne({email:email}) 
    //console.log(record)
    const id=record.id
    const {password}=req.body
    const newpass=await bcrypt.hash(password,10)
    await Reg.findByIdAndUpdate(id,{password:newpass})
    res.render('resetpasswordmessage.ejs')
    }catch(error){
        res.send(error.message)
    }
}
exports.resetpasswordmessage=(req,res)=>{
    try{
    res.render('resetpasswordmessage.ejs')
    }catch(error){
        res.send(error.message)
    }
}
exports.admindashboard=(req,res)=>{
    //console.log(req.session)
    try{
    const loginname=req.session.loginname
    res.render('admin/dashboard.ejs',{loginname})
    }catch(error){
        res.send(error.message)
    }
}
exports.logout=(req,res)=>{
    try{
    req.session.destroy()
    res.redirect('/')
    }catch(error){
        res.send(error.message)
    }
}
exports.allusers=async(req,res)=>{
    try{
    const loginname=req.session.loginname
    //console.log(loginname)
    const record=await Reg.find()
    //console.log(record)
    res.render('admin/users.ejs',{loginname,record})
    }catch(error){
        res.send(error.message)
    }
}

exports.userdelete=async(req,res)=>{
    //console.log(req.params.id)
    try{
    const id=req.params.id
    await Reg.findByIdAndDelete(id)
    res.redirect('/admin/users')
    }catch(error){
        res.send(error.message)
    }
}

exports.emailactivelink=async(req,res)=>{
    //console.log(req.params.email)
    try{
    const email=req.params.email
    const record=await Reg.findOne({email})
    //console.log(record)
    const id=record.id
    //console.log(id)
    await Reg.findByIdAndUpdate(id,{status:'verified'})
    res.render('activelinkmessage.ejs',{message:'your account has been active now.click below to login'})
    }catch(error){
        res.send(error.message)
    }
}

exports.usersprofiles=async(req,res)=>{
    //console.log(req.session)
    try{
    const loginname=req.session.loginname
    const record=await Reg.find({img:{$nin:['default.png']}})
    //console.log(record)
    res.render('userprofiles.ejs',{loginname,record})
    }catch(error){
        res.send(error.message)
    }
}

exports.profileupdateform=async(req,res)=>{
    try{
    const loginname=req.session.loginname
    const record=await Reg.findOne({email:loginname})
    //console.log(record)
    res.render('profileupdateform.ejs',{loginname,record,message:''})
    }catch(error){
        res.send(error.message)
    }
}
exports.userprofileupdate=async(req,res)=>{
    //console.log(req.file)
    
    //console.log(req.body)
    try{
    const{fname,lname,mobile,about}=req.body
    const loginname=req.session.loginname
    //console.log(loginname)
    const record=await Reg.findOne({email:loginname})
    //console.log(record)
    const id=record.id
    //console.log(id)
    if(req.file){
        const filename=req.file.filename
        await Reg.findByIdAndUpdate(id,{firstname:fname,lastname:lname,mobile:mobile,desc:about,img:filename})
    }else{
        await Reg.findByIdAndUpdate(id,{firstname:fname,lastname:lname,mobile:mobile,desc:about})
    }
    res.redirect('/profileupdate')
}catch(error){
    res.send(error.message)
}
}

exports.singledetail=async(req,res)=>{
    try{
    //console.log(req.params.id)
    const id=req.params.id
    //console.log(req.session)
    const loginname=req.session.loginname
    const record=await Reg.findById(id)
    //console.log(record)
    res.render('singledetail.ejs',{loginname,record})
    }catch(error){
        res.send(error.message)
    }
}

exports.roleupdate=async(req,res)=>{
    //console.log(req.params.id)
    try{
    const id=req.params.id
    const record=await Reg.findById(id)
    //console.log(record)
    let currentrole=null
    if(record.role=='subscribed'){
        currentrole='public'
    }else{
        currentrole='subscribed'
    }
    await Reg.findByIdAndUpdate(id,{role:currentrole})
    res.redirect('/admin/users')
}catch(error){
    res.send(error.message)
}
}


