const router=require('express').Router()//module
const regc=require('../controllers/regcontroller')
const multer=require('multer')

let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/profileimages')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,
    limits:{filesize:1024*1024*4}
})

function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/')
    }
}

function handlerole(req,res,next){
    if(req.session.role=='subscribed'){
        next()
    }else{
        res.send("You don't subscribed us to see this detail...please subscribed first.")
    }
}

router.get('/',regc.loginpage)
router.get('/signup',regc.signuppage)
router.post('/signup',regc.registration)
router.post('/',regc.logincheck)
router.get('/forgotform',regc.forgotform)
router.post('/forgotform',regc.sendlink)
router.get('/resetpasswordform/:email',regc.resetpasswordform)
router.post('/resetpasswordform/:email',regc.resetpasswordnow)
router.get('/resetpasswordmessage',regc.resetpasswordmessage)
router.get('/logout',regc.logout)
router.get('/emailactivelink/:email',regc.emailactivelink)
router.get('/userprofiles',handlelogin,regc.usersprofiles)
router.get('/profileupdate',handlelogin,regc.profileupdateform)
router.post('/profileupdate',upload.single('image'),regc.userprofileupdate)
router.get('/singledetail/:id',handlelogin,handlerole,regc.singledetail)







module.exports=router