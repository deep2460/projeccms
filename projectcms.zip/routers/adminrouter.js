const router=require('express').Router()//module
const regc=require('../controllers/regcontroller')

function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/')
    }
}

router.get('/',(req,res)=>{
    res.send('hello from admin router')
})
router.get('/dashboard',handlelogin,regc.admindashboard)
router.get('/users',handlelogin,regc.allusers)
router.get('/userdelete/:id',handlelogin,regc.userdelete)
router.get('/roleupdate/:id',handlelogin,regc.roleupdate)











module.exports=router